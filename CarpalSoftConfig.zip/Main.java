class AddTwoNumbers {
  public static void main(String[] args) {
     int num1 = 5, num2 = 15, sum;
      sum = num1 + num2;

      System.out.println("Sum of these numbers: "+sum);
   }
}

public class PrintingText{
  public static void main(String[] args){
    System.out.println("HELLO WORLD");
    System.out.println("Java programing is easy");
  }
}
public class GettingTheGreatest{
    public static void main(String[] args) {
        int num1,num2 ;
        System. out. println("The largest number of the two numbers is " + Math.max(num1,num2));
    }
}
public class Square{
	public static void main (String [] args)
	{
		int number;
		int square;
    for (number=1; number<6; number++);
		{
			square= number * number;//
			System.out.println(number+"\t"+square);
			
		}
	}

}